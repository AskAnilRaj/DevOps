# Hello_world_python
   
   - this is basic python hello world web application 
   - if you want test in your local the clone the repo and follow below steps 
        
        ### 1. install python-pip 
        ```
        - if it is ubuntu machine
            apt-get update -y
            apt-get install -y python-pip python-dev build-essential
        - if it is centos machine
            yum install -y python-pip
        ```
       
       ### 2. install plugins 
       ```
       - Run pip install -r requirements.txt
       ```
       
       ### 3. run the app
       ```
       - python app.py
       ```
