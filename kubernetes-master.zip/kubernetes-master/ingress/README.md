Create nginx controller
------
kubectl apply -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/controller-v1.1.0/deploy/static/provider/baremetal/deploy.yaml

``` For more info refer https://kubernetes.github.io/ingress-nginx/deploy/ ```
