INSERT INTO test.messages VALUES ('Devops');
INSERT INTO test.messages VALUES ('DeekshithSN');