CREATE TABLE test.messages (message VARCHAR(250));
INSERT INTO test.messages VALUES ('hello');
INSERT INTO test.messages VALUES ('hey');
