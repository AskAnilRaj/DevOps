- Mock interview video - https://youtu.be/lXGAJElFxaA
- Mock interview Answers - https://youtu.be/7WJ31VFk1_Y


GIT
---------------------------------------------------------------------------------------------------------------------------------
1. Lets say your organization has github and bitbucket to store code, you have cloned a repo onto your local and changed directory name. after some days one of your team members asks you to share clone link, how would you provide the same?
2. I have shell script to delete particular dependency ( repo is maven project ). before running the script i need to clone repo to my local, here point to note i should only clone master branch and only last commit ( last commit has all the code ) how would you do this?
3. what is submodule and why we need submodule?
4. Lets say you have changed 5 files a,b,c,d and e in a repo and you did git add ., now all the files are in staging area, now i decided not to commit file d. how would delete it from staging area?

Maven
--------------------------------------------------------------------------------------------------------------------------
5. what is multi module project in maven and what are the setting you want to do in multi module parent and child project? what is dependency management?
6. what is transitive dependency?

Jenkins 
--------------------------------------------------------------------------------------------------------
7. Have you worked on commit based job in jenkins? what settings you need to do in jenkins and github to setup commit based job?
8. you want to create 50 freestyle jobs with same configurations, but only change is job name. how would you achieve the same?
9. How can you copy job from your local jenkins instance to other local jenkins instance?

Unix and Shell scripting 
---------------------------------------------------------------------------------------------------------------------
10. write a script which accepts file or folder, if its folder delete it else print "this is a file"?
11. How to check whether particular port is already in use or not?
12. Logic for checking whether supplied string for a script is palindrome or not? what are all the commands you will use?
13. command to get number of lines in a file?

Ansible
-----------------------------------------------------------------------------------------------------------------------
14. Lets say i have 4 machines consider 1 as ansible master other 3 as nodes, what are the basic setup you need to do for ansible cluster?
15. what are ansible roles? why we need ansible roles? have you worked on ansible galaxy?
16. What are ansible facts?
17. Can we have windows machine as ansible master? as node?have you worked on any windows modules? can you list few?any extra configuration do we need to do?

Docker
------------------------------------------------------------------------------------------------------------------------------
18. Have you worked on multi-stage dockerfile and why we need that?
19. Lets say i have container which is attached with a volume, if container crashes what happens to volume?
20. can you copy a file form local to run container?


Kubernetes
--------------------------------------------------------------------------------------------------------------------------------------
21. what is init container and side-car container?can you give simple scenario where we use these conatiners?
22. which one is default deployment strategy? how it works?
23. command to check the container logs in pod?
24. what are the types of services present in kubernetes?
25. What is the link between pod and service?
