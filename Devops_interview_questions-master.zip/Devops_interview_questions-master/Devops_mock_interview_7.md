Git & Github 
---
1. Branching strategy? 
2. Need a script which identify inactive branches ( no commits since 2 months )?
3. How to set configs globally in git?

Maven
---
1. what are the tags that you came across in pom.xml?
2. Explain maven life cycle?
3. 
