General questions 
---
1. What do you mean by continues integration, continues delivery and continues deployment 

Git
---
2. Which version of git you have used? 
3. Difference between git merge and git rebase? 
4. What is git squash? 
5. Branching strategy used in your project? 
6. Command to list all commits? 

Maven 
---
7. Tell me 3 build lifecycle in maven? What does mvn site does?
8. Is there way by which we can set local repository as some other custom directory, other than .m2?
9. Settings that you make for mvn deploy?
10. What is the default value of packaging tag? What other values for other artifact types? 
11. What are GAV's? 

Jenkins
---
12. What are types jobs you have worked on?? 
13. Can we have job for pr and once merge is done the source branch should be deleted? 
14. How do you take Jenkins backup? 
15. Can you tell me importance of post block?? 

Docker
---
16. Why we need docker compose and docker swarm 
17. What's the difference between docker volume and docker mounting 
18. What is the importance of  .dockerigonre file, can name docker file with any other name? 
19. I need to delete all stopped containers and unused images command for that? 
20. How do you monitor docker in production 
21. Is it good to use docker compose in production 

Aws 
---
22. Services that you have worked on? 
23. Roles in IAM? 
24. I have 3 tier application, configure it with private and public subnet? 
25. How to replicate or create same machine with same configuration? 
26. Explain auto scalling in aws? 

Kubernetes
---
27. Why pods are not scheduled on master 
28. Why config maps are used 
29. What is the default deployment strategy 
30. Have you faced any issues while working k8s
31. What is service account, role, role binding and namespace 
32. Why we need helm

Scripting
----
33. You need to identify unused fields In values.yaml how would you approach this? 
34. What is exit status? 
35. Given machine, how will you identify which machine it is? 

Ansible 
----
36. What is ansible galaxy
37. What are handlers and notify in ansible playbook 
38. What are adhoc commands
