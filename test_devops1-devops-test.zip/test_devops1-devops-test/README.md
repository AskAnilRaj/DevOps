# test_devops
this is to test git activities 


# this devops traing, below are list of tools  

- unix
- shell script 
- docker
- k8s

```
kfhlhfljg
````


git fetch 
git pull
