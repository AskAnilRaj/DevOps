
echo "Hello world"
name=DeekshithSN
echo "my name is $name"
present_working_folder=$(pwd)
echo $present_working_folder
echo "$1----$2----$3----$4-----$5"
