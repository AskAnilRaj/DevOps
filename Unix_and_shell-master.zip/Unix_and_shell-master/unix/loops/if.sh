read number
if [ $number -gt 10 ]; then 
echo "the entered number is greater than 10"
fi
