read number
if [ $number -eq 10 ];then 
echo "number is equal to 10"
else
echo "number is greater or lesser than 10"
fi
