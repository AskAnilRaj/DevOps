if [ -e $1 ]; then 
echo "file is present"
fi
