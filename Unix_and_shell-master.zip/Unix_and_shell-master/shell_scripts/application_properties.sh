
source config
echo "Name=$nam" 
echo "Surname=$sur"
