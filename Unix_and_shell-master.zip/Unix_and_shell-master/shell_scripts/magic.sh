#! /bin/sh
echo "This is from $0"
