if [ -f $1 ];then 
echo "$1 is a file"
else
echo "this is a directory"
fi
