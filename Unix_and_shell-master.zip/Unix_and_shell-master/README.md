# Unix_and_shell
This repo has many shell script scenarios 

## Assignments 

1. what is the difference between single and double quotes in echo command?
2. how create a shortcut for a function in unix?
ex:- when i type in xyz then it should execute who, ls, pwd one after the other
3. search the files based on size ( hint use find command )
4. vi editor short cuts 
5. difference between running script as sh script_name & ./script_name
6. $*, $@ , $$, $?
7. need a script which returns "zero" if the supplied number ends with 0, print "five" if number ends with 5. else check whether given number is even or odd?  
8. script to check whether given string is palindrome or not ( string has to sent has param ), if user doesnt send any param i need print a message saying please supply string for which i want check palindrome condition?


