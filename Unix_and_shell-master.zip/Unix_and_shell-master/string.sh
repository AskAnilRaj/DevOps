if [ -z $1 ];then 
echo "please enter param"
else
echo "$1"
fi
