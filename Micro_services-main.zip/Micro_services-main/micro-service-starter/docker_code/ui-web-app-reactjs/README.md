# ui-web-app-reactjs
UI app to access microservices through API Gateway.
Developed in React.js

## Build Instruction
```
npm install

npm start

```
*App runs on port **8080***

Open http://localhost:8080 in browser
##
