# this is my fir project 

- 1 
- 2
- 3
- 4


name | phone
----| -------
fjh | 66
rbgr | 7777

**git config --global core.hooksPath /path/to/my/centralized/hooks**
