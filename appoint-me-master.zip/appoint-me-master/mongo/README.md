- docker command to run mongo db without password

```
docker run --name mongo-db -d -p 27017:27017 mongo
```

- mongo commands 

```
mongo
```

```
use db-name
```

```
show tables
```


```
db.collection_name.count()
```
