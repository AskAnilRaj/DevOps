- Application is written on ```ReactJs``` and need ```node 14``` run properly 

- To build the application command is ```  npm install ```

- To run the application ```  node index.js ```

- application run on port ``` 5000 ``` ( but you can customize it by changing the port in .env file )

##### Important notes to keep in mind 

In file .env, we should provide the proper information of mongo DB
