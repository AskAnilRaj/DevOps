- its node js project and needs ```node 14``` to run properly 



- To build the application you need to use command ``` npm install ```



- command run the application once build is done ``` npm start ```



- Applcation run on port ``` 3000  ```



#### Important ponits to remember 

in the base directory we have file .env, need to provide details of [appointme-user-api](https://github.com/DeekshithSN/appoint-me/tree/master/appointme-api)

```
REACT_APP_HI = hi
REACT_APP_API_HOST = http://machine_ip_where_api_is_deployed
REACT_APP_API_PORT = port_number_where_api_is_deployed
```
