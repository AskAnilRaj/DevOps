package com.afonsof;

import hudson.Extension;
import hudson.model.PageDecorator;

@Extension
public class JenkinsMaterialThemeDecorator extends PageDecorator {
}
