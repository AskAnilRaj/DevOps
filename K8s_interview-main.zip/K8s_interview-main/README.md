# Kubernetes 

-------------
### setup 
go to https://www.katacoda.com/courses/kubernetes/launch-single-node-cluster  --> start scenario --> in terminal screen type "minikube start --wait=false"

----------------
1. kubernetes-1 --> there are few error please correct and make sure pods are up are running as expected 
2. kuberntes-2 --> no errors list the craeted pod 



# Helm 

--------------
### setup 

go to https://www.katacoda.com/aptem/scenarios/helm --> start scenario --> wait for sometime, might take some time to setup kubernetes --> once that's done execute commands provide in left window on terminal window 

--------------

1. helm-1 --> correct the errors 
2. helm-2 --> when you deploy chart it will create ingress. By using helm i should stop creating ingress, but in templates folder i should have ingress.yaml
