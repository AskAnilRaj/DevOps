# devops_training

this is maven project 

to run this pre=requsites are you docker and maven installed 
