[assignments](https://github.com/DeekshithSN/Lets-Practice/blob/main/ShellScript/Assignments.md) - Refer this link for all the assignments 

[questions](https://github.com/DeekshithSN/Lets-Practice/blob/main/ShellScript/Questions.md) - Refer this link for all the questions 
