echo "the script name is $0"
