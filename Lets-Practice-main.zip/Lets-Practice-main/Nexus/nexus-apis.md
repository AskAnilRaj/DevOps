curl -u admin:admin -X GET 'http://34.125.103.187:8081/service/rest/v1/search?repository=internal'
