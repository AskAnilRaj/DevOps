# jenkins shared library structure
A template structure for Jenkins Shared Library
