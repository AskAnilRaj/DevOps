from pre_commit.main import main


if __name__ == '__main__':
    exit(main())
