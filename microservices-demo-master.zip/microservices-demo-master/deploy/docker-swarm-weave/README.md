See the [documentation](../../docs/deployment/docker-swarm.md) on how to deploy Sock Shop using Docker Swarm.
