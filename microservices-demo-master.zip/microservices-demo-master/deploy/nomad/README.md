See the [documentation](https://microservices-demo.github.io/deployment/nomad.html) on how to deploy Sock Shop using Nomad.
