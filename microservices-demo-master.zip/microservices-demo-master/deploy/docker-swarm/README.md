See the [documentation](https://microservices-demo.github.io/deployment/docker-swarm.html) on how to deploy Sock Shop using Docker Swarm.
