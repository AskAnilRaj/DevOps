This deployment will launch a Weave-enabled Amazon ECS cluster.

See the [documentation](https://microservices-demo.github.io/deployment/ecs-weave-shippable.html) on how to deploy Sock Shop using AWS ECS with automated CI/CD using Shippable.
